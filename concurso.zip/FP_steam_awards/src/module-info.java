module fp_steam_awards {
	requires java.desktop;
}