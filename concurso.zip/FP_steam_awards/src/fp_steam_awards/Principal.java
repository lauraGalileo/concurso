package fp_steam_awards;

public class Principal {

	public static void main(String[] args) {
		Ventana ven = new Ventana();

	}

}
